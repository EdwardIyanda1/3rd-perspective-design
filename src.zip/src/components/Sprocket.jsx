import Sprocket from '../components/Sprocket'

// Leadership and agency team members mapped from the group chat introduce sequence
const leadership = [
  { name: 'Abdullah Nola', role: 'Founder & CEO', tag: 'Nola / Noly / Noly The Sage' },
  { name: 'Popoola Moyinoluwa Mabel', role: 'Co-founder & Creative Director', tag: 'Mabel / Head of Videography & Photography' },
]

const teamMembers = [
  { name: 'Albertine Onabamiro', alias: 'AB', skill: 'Video making & Photography' },
  { name: 'Beecroft Taiwo', alias: 'Taiwo / Beecroft', skill: 'Photography' },
  { name: 'Bello Abdul Qoyum Oriola', alias: 'Liam', skill: 'Videography, Photography & Graphic Design' },
  { name: 'Edward M. Iyanda', alias: 'Edward', skill: 'Graphic Design' },
]

export default function About() {
  return (
    <section className="bg-[#0C0C0D]">
      <div className="max-w-4xl mx-auto px-4 py-24">
        <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-[#D6293A]">
          Reel 01   About
        </span>
        <h1 className="font-display text-5xl md:text-6xl text-[#F3F1EC] mt-3 mb-6">
          ABOUT US
        </h1>
        <p className="text-[#B9B7B2] leading-relaxed max-w-2xl mb-16">
          Third Perspective Media is a media agency built on collaboration,
          creativity, and consistency. We believe every brand has a story
          worth telling well   through video, photography, and design that
          moves people.
        </p>

        {/* Leadership Section */}
        <div className="flex items-center gap-3 mb-8">
          <h2 className="font-display text-2xl tracking-wide text-[#F3F1EC]">
            LEADERSHIP
          </h2>
          <span className="flex-1 h-px bg-white/10" />
        </div>
        <div className="grid sm:grid-cols-2 gap-px bg-white/10 mb-16">
          {leadership.map((t) => (
            <div key={t.name} className="bg-[#17171B]">
              <Sprocket tone="light" count={10} className="py-2" />
              <div className="p-6">
                <p className="font-display text-2xl tracking-wide text-[#F3F1EC]">
                  {t.name}
                </p>
                <p className="font-mono text-xs uppercase tracking-[0.15em] text-[#D6293A] mt-1">
                  {t.role}
                </p>
                <p className="font-mono text-[11px] text-[#8A8A8E] mt-2">
                  {t.tag}
                </p>
              </div>
              <Sprocket tone="light" count={10} className="py-2" />
            </div>
          ))}
        </div>

        {/* Creative Crew Section */}
        <div className="flex items-center gap-3 mb-8">
          <h2 className="font-display text-2xl tracking-wide text-[#F3F1EC]">
            CREATIVE CREW
          </h2>
          <span className="flex-1 h-px bg-white/10" />
        </div>
        <div className="grid sm:grid-cols-2 gap-px bg-white/10">
          {teamMembers.map((m) => (
            <div key={m.name} className="bg-[#17171B]">
              <Sprocket tone="light" count={10} className="py-2" />
              <div className="p-6">
                <div className="flex items-baseline justify-between gap-2">
                  <p className="font-display text-xl tracking-wide text-[#F3F1EC]">
                    {m.name}
                  </p>
                  <span className="font-mono text-[10px] uppercase tracking-wider text-[#8A8A8E] bg-white/5 px-2 py-0.5 rounded">
                    {m.alias}
                  </span>
                </div>
                <p className="font-mono text-xs uppercase tracking-[0.15em] text-[#D6293A] mt-2">
                  {m.skill}
                </p>
              </div>
              <Sprocket tone="light" count={10} className="py-2" />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}